<?php

class Model_diagnosis extends MY_Model
{
	const DB_TABLE = 'ra_diagnosis';
	const DB_TABLE_PK = 'id';

    /**
     * 
     * Diagnosis
     */
    public $name;


}