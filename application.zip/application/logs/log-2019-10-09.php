<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-10-09 11:57:58 --> 404 Page Not Found: Assets/bower_components
ERROR - 2019-10-09 11:58:20 --> 404 Page Not Found: Assets/bower_components
ERROR - 2019-10-09 11:59:32 --> 404 Page Not Found: Assets/bower_components
ERROR - 2019-10-09 11:59:47 --> 404 Page Not Found: Assets/bower_components
